/**
 * ALMA Regulatory Scraper Engine
 * Fetches regulatory article content, detects changes, and stores amendment history.
 * Supports EU AI Act, UK DSIT, and NIST AI RMF with framework-specific parsers.
 */
import { createHash } from 'crypto';
import * as cheerio from 'cheerio';
import { diffLines } from 'diff';
import pool from '../db/pool.js';

// ── Framework-specific scrape configs ──
const SCRAPE_CONFIGS = {
  'eu-ai-act': {
    baseUrl: 'https://artificialintelligenceact.eu/article/',
    articleSelector: '.entry-content',
    titleSelector: 'h1.entry-title',
    // Articles we track (from our regulatory_articles table)
    getArticleUrl: (num) => `https://artificialintelligenceact.eu/article/${num}/`,
    parseContent: ($, html) => {
      const content = $(html).find('.entry-content');
      // Remove nav elements, sidebars, and scripts
      content.find('nav, .sidebar, script, .related-articles, .newsletter-signup').remove();
      return {
        text: content.text().trim(),
        html: content.html()?.trim() || '',
        lastModified: $('meta[property="article:modified_time"]').attr('content') || null
      };
    }
  },

  'uk-ai': {
    baseUrl: 'https://www.gov.uk/government/publications/ai-regulation-a-pro-innovation-approach/',
    getArticleUrl: (key) => {
      const urls = {
        'P1': 'https://www.gov.uk/government/publications/ai-regulation-a-pro-innovation-approach/white-paper',
        'ICO-AI': 'https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/',
        'DUA-2025': 'https://www.legislation.gov.uk/ukpga/2025/1/contents',
        'AISI': 'https://www.gov.uk/government/organisations/ai-safety-institute'
      };
      return urls[key] || null;
    },
    parseContent: ($, html) => {
      const content = $(html).find('.govspeak, .gem-c-govspeak, main');
      content.find('nav, .sidebar, script').remove();
      return {
        text: content.text().trim(),
        html: content.html()?.trim() || '',
        lastModified: $('meta[name="dc.date.modified"]').attr('content') || null
      };
    }
  },

  'us-nist': {
    baseUrl: 'https://airc.nist.gov/airmf-resources/',
    getArticleUrl: (key) => {
      const urls = {
        'GOV': 'https://airc.nist.gov/airmf-resources/playbook/?function=Govern',
        'MAP': 'https://airc.nist.gov/airmf-resources/playbook/?function=Map',
        'MEA': 'https://airc.nist.gov/airmf-resources/playbook/?function=Measure',
        'MAN': 'https://airc.nist.gov/airmf-resources/playbook/?function=Manage',
        'CORE': 'https://airc.nist.gov/airmf-resources/airmf/5-sec-core/'
      };
      return urls[key] || null;
    },
    parseContent: ($, html) => {
      const content = $(html).find('main, .main-content, #main-content');
      content.find('nav, script, header, footer').remove();
      return {
        text: content.text().trim(),
        html: content.html()?.trim() || '',
        lastModified: null
      };
    }
  }
};

// ── Content hashing ──
function hashContent(text) {
  return createHash('sha256').update(text).digest('hex');
}

// ── Generate change summary from diff ──
function generateChangeSummary(oldText, newText) {
  const changes = diffLines(oldText, newText);
  const added = changes.filter(c => c.added).map(c => c.value.trim()).filter(Boolean);
  const removed = changes.filter(c => c.removed).map(c => c.value.trim()).filter(Boolean);

  const parts = [];
  if (added.length > 0) parts.push(`${added.length} section(s) added or modified`);
  if (removed.length > 0) parts.push(`${removed.length} section(s) removed or replaced`);

  return {
    summary: parts.join('; ') || 'Minor formatting changes detected',
    diffText: changes
      .filter(c => c.added || c.removed)
      .map(c => `${c.added ? '+' : '-'} ${c.value.substring(0, 200)}`)
      .join('\n')
      .substring(0, 2000) // Cap diff storage
  };
}

// ── Fetch a single page with retry ──
async function fetchPage(url, retries = 3) {
  const fetch = (await import('node-fetch')).default;
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'ALMA-Regulatory-Monitor/1.0 (Governance Research; contact@humanintegrityadvisory.com)',
          'Accept': 'text/html,application/xhtml+xml',
          'Accept-Language': 'en-GB,en;q=0.9'
        },
        timeout: 15000
      });
      if (!response.ok) {
        if (response.status === 429) {
          // Rate limited — back off
          const wait = Math.pow(2, i) * 5000;
          console.warn(`Rate limited on ${url}, waiting ${wait}ms...`);
          await new Promise(r => setTimeout(r, wait));
          continue;
        }
        throw new Error(`HTTP ${response.status} for ${url}`);
      }
      return await response.text();
    } catch (err) {
      if (i === retries - 1) throw err;
      await new Promise(r => setTimeout(r, 2000 * (i + 1)));
    }
  }
}

// ── Scrape a single article ──
async function scrapeArticle(frameworkId, articleNum) {
  const config = SCRAPE_CONFIGS[frameworkId];
  if (!config) throw new Error(`No scrape config for framework: ${frameworkId}`);

  const url = config.getArticleUrl(articleNum);
  if (!url) return { articleNum, status: 'skipped', reason: 'No URL configured' };

  try {
    const html = await fetchPage(url);
    const $ = cheerio.load(html);
    const parsed = config.parseContent($, html);

    if (!parsed.text || parsed.text.length < 50) {
      return { articleNum, status: 'empty', reason: 'Insufficient content parsed' };
    }

    const contentHash = hashContent(parsed.text);

    // Get previous scrape
    const prevRes = await pool.query(
      `SELECT content_hash, scraped_content FROM article_scrape_history
       WHERE framework_id = $1 AND article_num = $2
       ORDER BY scraped_at DESC LIMIT 1`,
      [frameworkId, articleNum]
    );

    const previousHash = prevRes.rows.length > 0 ? prevRes.rows[0].content_hash : null;
    const previousContent = prevRes.rows.length > 0 ? prevRes.rows[0].scraped_content : '';
    const changeDetected = previousHash !== null && previousHash !== contentHash;

    let changeSummary = null;
    let diffText = null;

    if (changeDetected) {
      const diff = generateChangeSummary(previousContent, parsed.text);
      changeSummary = diff.summary;
      diffText = diff.diffText;
    }

    // Store scrape result
    await pool.query(
      `INSERT INTO article_scrape_history
       (framework_id, article_num, scraped_content, content_hash, change_detected, change_summary, diff_text, source_url)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [frameworkId, articleNum, parsed.text, contentHash, changeDetected, changeSummary, diffText, url]
    );

    // Update article last_verified date
    await pool.query(
      `UPDATE regulatory_articles SET last_verified = CURRENT_DATE
       WHERE framework_id = $1 AND article_num = $2`,
      [frameworkId, articleNum]
    );

    // Update article summary if this is a first scrape (no previous data)
    if (previousHash === null && parsed.text.length > 100) {
      // Don't overwrite manually curated summaries
    }

    return {
      articleNum,
      status: changeDetected ? 'changed' : 'unchanged',
      contentHash,
      changeSummary,
      contentLength: parsed.text.length
    };
  } catch (err) {
    return { articleNum, status: 'error', error: err.message };
  }
}

// ── Scrape all articles for a framework ──
export async function scrapeFramework(frameworkId) {
  const config = SCRAPE_CONFIGS[frameworkId];
  if (!config) throw new Error(`No scrape config for framework: ${frameworkId}`);

  // Get articles to scrape
  const { rows: articles } = await pool.query(
    `SELECT article_num FROM regulatory_articles WHERE framework_id = $1 AND active = TRUE`,
    [frameworkId]
  );

  const results = [];
  for (const art of articles) {
    // Rate limit: 2 seconds between requests to be respectful
    await new Promise(r => setTimeout(r, 2000));
    const result = await scrapeArticle(frameworkId, art.article_num);
    results.push(result);
  }

  const changed = results.filter(r => r.status === 'changed').length;
  const errors = results.filter(r => r.status === 'error').length;

  // Log scrape run
  await pool.query(
    `INSERT INTO scrape_runs (framework_id, articles_scraped, changes_detected, errors, completed_at)
     VALUES ($1, $2, $3, $4, NOW())`,
    [frameworkId, results.length, changed, errors]
  );

  return {
    framework: frameworkId,
    total: results.length,
    changed,
    unchanged: results.filter(r => r.status === 'unchanged').length,
    errors,
    skipped: results.filter(r => r.status === 'skipped').length,
    details: results
  };
}

// ── Scrape all active frameworks ──
export async function scrapeAllFrameworks() {
  const { rows: frameworks } = await pool.query(
    `SELECT id FROM regulatory_frameworks WHERE active = TRUE`
  );

  const results = {};
  for (const fw of frameworks) {
    try {
      results[fw.id] = await scrapeFramework(fw.id);
    } catch (err) {
      results[fw.id] = { error: err.message };
    }
  }
  return results;
}
