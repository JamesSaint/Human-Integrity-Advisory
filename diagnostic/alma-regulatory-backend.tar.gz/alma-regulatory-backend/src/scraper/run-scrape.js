/**
 * Manual scrape runner — CLI tool for triggering scrapes.
 * Usage: node src/scraper/run-scrape.js [--framework=eu-ai-act]
 */
import 'dotenv/config';
import { scrapeAllFrameworks, scrapeFramework } from './index.js';

const args = process.argv.slice(2);
const fwArg = args.find(a => a.startsWith('--framework='));
const frameworkId = fwArg ? fwArg.split('=')[1] : null;

async function run() {
  console.log('─── ALMA Regulatory Scraper ───');
  console.log(`Timestamp: ${new Date().toISOString()}`);

  try {
    let results;
    if (frameworkId) {
      console.log(`Scraping framework: ${frameworkId}`);
      results = { [frameworkId]: await scrapeFramework(frameworkId) };
    } else {
      console.log('Scraping all active frameworks...');
      results = await scrapeAllFrameworks();
    }

    // Print summary
    for (const [fw, result] of Object.entries(results)) {
      console.log(`\n── ${fw} ──`);
      if (result.error) {
        console.log(`  ERROR: ${result.error}`);
        continue;
      }
      console.log(`  Total: ${result.total} articles`);
      console.log(`  Changed: ${result.changed}`);
      console.log(`  Unchanged: ${result.unchanged}`);
      console.log(`  Errors: ${result.errors}`);
      console.log(`  Skipped: ${result.skipped}`);

      if (result.changed > 0) {
        console.log('\n  ⚠ AMENDMENTS DETECTED:');
        result.details
          .filter(d => d.status === 'changed')
          .forEach(d => {
            console.log(`    Article ${d.articleNum}: ${d.changeSummary}`);
          });
      }
    }
    
    console.log('\n─── Scrape complete ───');
    process.exit(0);
  } catch (err) {
    console.error('Scrape failed:', err);
    process.exit(1);
  }
}

run();
