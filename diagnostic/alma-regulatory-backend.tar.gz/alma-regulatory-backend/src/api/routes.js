/**
 * ALMA Regulatory API Routes
 * Serves regulatory framework data, article content, amendment history,
 * and ALMA→regulatory mappings to the diagnostic frontend.
 */
import { Router } from 'express';
import pool from '../db/pool.js';
import { scrapeFramework } from '../scraper/index.js';

const router = Router();

// ── GET /api/frameworks ──
// Returns all active regulatory frameworks
router.get('/frameworks', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, name, short_name, citation, base_url, jurisdiction, active, version, last_updated
       FROM regulatory_frameworks ORDER BY active DESC, name`
    );
    res.json({ frameworks: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/frameworks/:id/articles ──
// Returns all articles for a given framework, with latest scraped content
router.get('/frameworks/:id/articles', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT ra.article_num, ra.title, ra.summary, ra.url_path, ra.penalty_tier,
              ra.enforcement_date, ra.chapter, ra.last_verified,
              asc2.scraped_content, asc2.scraped_at
       FROM regulatory_articles ra
       LEFT JOIN LATERAL (
         SELECT scraped_content, scraped_at
         FROM article_scrape_history ash
         WHERE ash.framework_id = ra.framework_id AND ash.article_num = ra.article_num
         ORDER BY scraped_at DESC LIMIT 1
       ) asc2 ON TRUE
       WHERE ra.framework_id = $1 AND ra.active = TRUE
       ORDER BY ra.article_num::INT`,
      [id]
    );
    res.json({ framework_id: id, articles: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/frameworks/:id/articles/:num ──
// Returns a single article with its full amendment history
router.get('/frameworks/:id/articles/:num', async (req, res) => {
  try {
    const { id, num } = req.params;
    const articleRes = await pool.query(
      `SELECT * FROM regulatory_articles WHERE framework_id = $1 AND article_num = $2`,
      [id, num]
    );
    if (articleRes.rows.length === 0) return res.status(404).json({ error: 'Article not found' });

    const historyRes = await pool.query(
      `SELECT scraped_at, content_hash, change_detected, change_summary
       FROM article_scrape_history
       WHERE framework_id = $1 AND article_num = $2
       ORDER BY scraped_at DESC LIMIT 20`,
      [id, num]
    );

    res.json({
      article: articleRes.rows[0],
      history: historyRes.rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/frameworks/:id/amendments ──
// Returns recent amendments/changes detected across all articles
router.get('/frameworks/:id/amendments', async (req, res) => {
  try {
    const { id } = req.params;
    const since = req.query.since || new Date(Date.now() - 90 * 86400000).toISOString(); // default 90 days

    const { rows } = await pool.query(
      `SELECT ash.article_num, ra.title, ash.scraped_at, ash.change_summary,
              ash.change_detected, ash.diff_text
       FROM article_scrape_history ash
       JOIN regulatory_articles ra ON ra.framework_id = ash.framework_id AND ra.article_num = ash.article_num
       WHERE ash.framework_id = $1 AND ash.change_detected = TRUE AND ash.scraped_at >= $2
       ORDER BY ash.scraped_at DESC`,
      [id, since]
    );
    res.json({ framework_id: id, since, amendments: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/frameworks/:id/timeline ──
// Returns enforcement timeline for a framework
router.get('/frameworks/:id/timeline', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT milestone, enforcement_date, description, status
       FROM regulatory_enforcement_timeline
       WHERE framework_id = $1
       ORDER BY enforcement_date`,
      [id]
    );
    res.json({ framework_id: id, timeline: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/mappings/:framework_id ──
// Returns all ALMA → regulatory mappings for a given framework
router.get('/mappings/:framework_id', async (req, res) => {
  try {
    const { framework_id } = req.params;
    const { rows } = await pool.query(
      `SELECT m.alma_construct, m.alma_key, m.article_num, m.mapping_priority,
              m.risk_narrative_critical, m.risk_narrative_fragile, m.risk_narrative_robust,
              m.rationale, ra.title AS article_title, ra.penalty_tier
       FROM alma_regulatory_mappings m
       JOIN regulatory_articles ra ON ra.framework_id = m.framework_id AND ra.article_num = m.article_num
       WHERE m.framework_id = $1
       ORDER BY m.alma_construct, m.alma_key, m.mapping_priority`,
      [framework_id]
    );
    res.json({ framework_id, mappings: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/risk/:respondent_id ──
// Returns regulatory risk profile for a specific respondent
router.get('/risk/:respondent_id', async (req, res) => {
  try {
    const { respondent_id } = req.params;
    const { rows } = await pool.query(
      `SELECT * FROM v_regulatory_risk_per_respondent WHERE respondent_id = $1
       ORDER BY CASE risk_level WHEN 'high' THEN 0 WHEN 'elevated' THEN 1 ELSE 2 END`,
      [respondent_id]
    );
    res.json({ respondent_id, risks: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/scrape/:framework_id ──
// Manually triggers a scrape for a specific framework (admin)
router.post('/scrape/:framework_id', async (req, res) => {
  try {
    const { framework_id } = req.params;
    const result = await scrapeFramework(framework_id);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
