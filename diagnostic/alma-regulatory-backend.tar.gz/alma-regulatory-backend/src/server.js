/**
 * ALMA Regulatory Backend — Server
 * Exposes API for regulatory framework data and runs scheduled scraping.
 */
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cron from 'node-cron';
import { createLogger, format, transports } from 'winston';
import { pool, testConnection } from './db/pool.js';
import { scrapeAllFrameworks } from './scraper/index.js';
import apiRouter from './api/routes.js';

const app = express();
const PORT = process.env.PORT || 3001;

// ── Logger ──
export const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(format.timestamp(), format.json()),
  transports: [
    new transports.Console({ format: format.combine(format.colorize(), format.simple()) }),
    new transports.File({ filename: 'logs/scraper.log', maxsize: 5242880, maxFiles: 5 })
  ]
});

// ── Middleware ──
app.use(cors({
  origin: (process.env.CORS_ORIGINS || '*').split(',').map(s => s.trim()),
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// ── API Routes ──
app.use('/api', apiRouter);

// ── Health check ──
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ status: 'error', message: err.message });
  }
});

// ── Scheduled scraping ──
const schedule = process.env.SCRAPE_SCHEDULE || '0 3 * * *';
if (cron.validate(schedule)) {
  cron.schedule(schedule, async () => {
    logger.info('Starting scheduled regulatory scrape...');
    try {
      const results = await scrapeAllFrameworks();
      logger.info('Scheduled scrape complete', { results });
    } catch (err) {
      logger.error('Scheduled scrape failed', { error: err.message });
    }
  });
  logger.info(`Scrape scheduled: ${schedule}`);
}

// ── Start ──
async function start() {
  await testConnection();
  app.listen(PORT, () => {
    logger.info(`ALMA Regulatory Backend running on port ${PORT}`);
  });
}

start().catch(err => {
  logger.error('Failed to start server', { error: err.message });
  process.exit(1);
});
