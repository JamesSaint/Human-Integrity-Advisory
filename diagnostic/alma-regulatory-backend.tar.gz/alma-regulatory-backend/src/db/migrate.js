/**
 * Database migration for ALMA Regulatory Scraper
 * Creates scrape history and run tracking tables.
 * Run: node src/db/migrate.js
 */
import 'dotenv/config';
import pool from './pool.js';

const MIGRATION_SQL = `
-- ─────────────────────────────────────────────────────────────
-- TABLE: article_scrape_history
-- Stores every scrape result for every article, enabling
-- amendment detection and change tracking over time.
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS article_scrape_history (
  id               BIGSERIAL    PRIMARY KEY,
  framework_id     VARCHAR(30)  NOT NULL REFERENCES regulatory_frameworks(id) ON DELETE CASCADE,
  article_num      VARCHAR(10)  NOT NULL,
  scraped_content  TEXT,                             -- Full text content at scrape time
  content_hash     VARCHAR(64)  NOT NULL,            -- SHA-256 hash for change detection
  change_detected  BOOLEAN      DEFAULT FALSE,       -- TRUE if content changed since last scrape
  change_summary   TEXT,                             -- Human-readable summary of changes
  diff_text        TEXT,                             -- Abbreviated diff output
  source_url       VARCHAR(500),                     -- URL that was scraped
  scraped_at       TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scrape_hist_fw      ON article_scrape_history(framework_id);
CREATE INDEX IF NOT EXISTS idx_scrape_hist_article ON article_scrape_history(framework_id, article_num);
CREATE INDEX IF NOT EXISTS idx_scrape_hist_changed ON article_scrape_history(change_detected) WHERE change_detected = TRUE;
CREATE INDEX IF NOT EXISTS idx_scrape_hist_date    ON article_scrape_history(scraped_at);

-- ─────────────────────────────────────────────────────────────
-- TABLE: scrape_runs
-- Tracks each scrape execution for monitoring and audit
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scrape_runs (
  id                SERIAL       PRIMARY KEY,
  framework_id      VARCHAR(30)  NOT NULL REFERENCES regulatory_frameworks(id) ON DELETE CASCADE,
  articles_scraped  INTEGER      DEFAULT 0,
  changes_detected  INTEGER      DEFAULT 0,
  errors            INTEGER      DEFAULT 0,
  completed_at      TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scrape_runs_fw   ON scrape_runs(framework_id);
CREATE INDEX IF NOT EXISTS idx_scrape_runs_date ON scrape_runs(completed_at);

-- ─────────────────────────────────────────────────────────────
-- VIEW: v_latest_article_content
-- Returns the most recent scraped content for each article
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW v_latest_article_content AS
SELECT DISTINCT ON (framework_id, article_num)
  framework_id, article_num, scraped_content, content_hash,
  scraped_at, source_url
FROM article_scrape_history
ORDER BY framework_id, article_num, scraped_at DESC;

-- ─────────────────────────────────────────────────────────────
-- VIEW: v_amendment_log
-- All detected amendments with article details
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW v_amendment_log AS
SELECT
  ash.framework_id,
  rf.short_name AS framework_name,
  ash.article_num,
  ra.title AS article_title,
  ash.change_summary,
  ash.diff_text,
  ash.scraped_at AS detected_at,
  ash.source_url
FROM article_scrape_history ash
JOIN regulatory_frameworks rf ON rf.id = ash.framework_id
JOIN regulatory_articles ra ON ra.framework_id = ash.framework_id AND ra.article_num = ash.article_num
WHERE ash.change_detected = TRUE
ORDER BY ash.scraped_at DESC;

-- ─────────────────────────────────────────────────────────────
-- VIEW: v_scrape_health
-- Monitoring view for scrape operations
-- ─────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW v_scrape_health AS
SELECT
  sr.framework_id,
  rf.short_name,
  COUNT(*) AS total_runs,
  MAX(sr.completed_at) AS last_run,
  SUM(sr.changes_detected) AS total_amendments_detected,
  SUM(sr.errors) AS total_errors,
  ROUND(AVG(sr.articles_scraped), 0) AS avg_articles_per_run
FROM scrape_runs sr
JOIN regulatory_frameworks rf ON rf.id = sr.framework_id
GROUP BY sr.framework_id, rf.short_name;

-- Comments
COMMENT ON TABLE article_scrape_history IS 'Full scrape history per article. Each row = one scrape attempt. Change detection via content_hash comparison.';
COMMENT ON TABLE scrape_runs IS 'Audit log of scrape executions. One row per framework per run.';
COMMENT ON VIEW v_latest_article_content IS 'Latest scraped content for each article. Use for real-time regulatory lookups.';
COMMENT ON VIEW v_amendment_log IS 'Chronological log of all detected regulatory amendments. Feed into frontend amendment alerts.';
`;

async function migrate() {
  console.log('Running ALMA Regulatory Scraper migration...');
  try {
    await pool.query(MIGRATION_SQL);
    console.log('Migration complete.');
    process.exit(0);
  } catch (err) {
    console.error('Migration failed:', err.message);
    process.exit(1);
  }
}

migrate();
